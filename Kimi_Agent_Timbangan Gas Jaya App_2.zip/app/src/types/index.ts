// Types for Timbangan Gas Jaya Application

export interface WeighingData {
  id?: string;
  tanggal: string;
  jam: string;
  namaSupir: string;
  platNomor: string;
  namaSupplier: string;
  beratKotor: number;
  tara: number;
  potonganPersen: number;
  potonganKg: number;
  beratBersih: number;
  hargaPerKg: number;
  subtotal: number;
  biayaAdmin: number;
  totalTransfer: number;
  statusPembayaran: 'LUNAS' | 'BELUM LUNAS';
  dibayar: number;
  terutang: number;
}

export interface Supplier {
  id?: string;
  namaSupplier: string;
  namaRekening: string;
  noRekening: string;
  bank: string;
  hargaTerakhir: number;
}

export interface Transaction {
  id?: string;
  tanggal: string;
  supplier: string;
  jam: string;
  berat: number;
  hargaPerKg: number;
  totalHarga: number;
  admin: number;
  totalBayar: number;
  dibayar: number;
  terutang: number;
  anRekening: string;
  noRekening: string;
  bank: string;
  keterangan: string;
}
