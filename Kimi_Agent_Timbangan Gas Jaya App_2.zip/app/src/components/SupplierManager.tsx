import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Users, Plus, Trash2, Building2, CreditCard, Landmark } from 'lucide-react';
import type { Supplier } from '@/types';

interface SupplierManagerProps {
  suppliers: Supplier[];
  onAdd: (supplier: Supplier) => void;
  onDelete: (namaSupplier: string) => void;
}

export function SupplierManager({ suppliers, onAdd, onDelete }: SupplierManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({
    hargaTerakhir: 3600,
  });

  const handleSubmit = () => {
    if (!newSupplier.namaSupplier || !newSupplier.namaRekening || !newSupplier.noRekening || !newSupplier.bank) {
      alert('Mohon lengkapi semua data supplier!');
      return;
    }

    onAdd({
      namaSupplier: newSupplier.namaSupplier,
      namaRekening: newSupplier.namaRekening,
      noRekening: newSupplier.noRekening,
      bank: newSupplier.bank,
      hargaTerakhir: Number(newSupplier.hargaTerakhir) || 3600,
    });

    setNewSupplier({ hargaTerakhir: 3600 });
    setIsDialogOpen(false);
  };

  return (
    <Card className="w-full">
      <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-800 text-white rounded-t-lg">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-xl">
            <Users className="w-6 h-6" />
            Data Supplier
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="secondary" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Tambah Supplier
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Building2 className="w-5 h-5" />
                  Tambah Supplier Baru
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="namaSupplier">Nama Supplier</Label>
                  <Input
                    id="namaSupplier"
                    placeholder="Contoh: SAMURAI"
                    value={newSupplier.namaSupplier || ''}
                    onChange={(e) => setNewSupplier(prev => ({ ...prev, namaSupplier: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="namaRekening">Nama Rekening Penerima</Label>
                  <Input
                    id="namaRekening"
                    placeholder="Contoh: ABDU AL AMIN"
                    value={newSupplier.namaRekening || ''}
                    onChange={(e) => setNewSupplier(prev => ({ ...prev, namaRekening: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="noRekening">Nomor Rekening</Label>
                  <Input
                    id="noRekening"
                    placeholder="Contoh: 1490013834462"
                    value={newSupplier.noRekening || ''}
                    onChange={(e) => setNewSupplier(prev => ({ ...prev, noRekening: e.target.value }))}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bank">Bank</Label>
                    <Input
                      id="bank"
                      placeholder="Contoh: MANDIRI"
                      value={newSupplier.bank || ''}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, bank: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hargaTerakhir">Harga Terakhir (Rp/kg)</Label>
                    <Input
                      id="hargaTerakhir"
                      type="number"
                      placeholder="3600"
                      value={newSupplier.hargaTerakhir || ''}
                      onChange={(e) => setNewSupplier(prev => ({ ...prev, hargaTerakhir: Number(e.target.value) }))}
                    />
                  </div>
                </div>
                <Button onClick={handleSubmit} className="w-full flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Simpan Supplier
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader className="sticky top-0 bg-gray-50">
              <TableRow>
                <TableHead>Nama Supplier</TableHead>
                <TableHead>A/N Rekening</TableHead>
                <TableHead>No. Rekening</TableHead>
                <TableHead>Bank</TableHead>
                <TableHead>Harga/kg</TableHead>
                <TableHead className="w-20 text-center">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {suppliers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    Belum ada data supplier
                  </TableCell>
                </TableRow>
              ) : (
                suppliers.map((supplier) => (
                  <TableRow key={supplier.namaSupplier} className="hover:bg-gray-50">
                    <TableCell className="font-medium">{supplier.namaSupplier}</TableCell>
                    <TableCell className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-gray-400" />
                      {supplier.namaRekening}
                    </TableCell>
                    <TableCell className="font-mono text-sm">{supplier.noRekening}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                        <Landmark className="w-3 h-3" />
                        {supplier.bank}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono">
                      Rp {supplier.hargaTerakhir.toLocaleString('id-ID')}
                    </TableCell>
                    <TableCell className="text-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          if (confirm(`Yakin ingin menghapus supplier ${supplier.namaSupplier}?`)) {
                            onDelete(supplier.namaSupplier);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </ScrollArea>
        <div className="p-4 border-t bg-gray-50">
          <div className="text-sm text-gray-600">
            Total Supplier: <span className="font-bold">{suppliers.length}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
