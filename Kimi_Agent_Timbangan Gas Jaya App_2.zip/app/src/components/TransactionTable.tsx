import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Label } from '@/components/ui/label';
import { Search, Trash2, FileSpreadsheet, Eye, Truck, User, CheckCircle2, XCircle } from 'lucide-react';
import type { WeighingData, Supplier } from '@/types';

interface TransactionTableProps {
  transactions: WeighingData[];
  suppliers: Supplier[];
  onDelete: (id: string) => void;
  onUpdate?: (id: string, data: Partial<WeighingData>) => void;
}

export function TransactionTable({ transactions, suppliers, onDelete, onUpdate }: TransactionTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTransaction, setSelectedTransaction] = useState<WeighingData | null>(null);

  const filteredTransactions = transactions.filter(t => 
    t.namaSupir?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.namaSupplier?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.platNomor?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatRupiah = (value: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(value);
  };

  const getSupplierInfo = (supplierName: string) => {
    return suppliers.find(s => s.namaSupplier === supplierName);
  };

  const exportToCSV = () => {
    const headers = [
      'Tanggal', 'Supplier', 'Jam', 'Nama Supir', 'Plat Nomor',
      'Berat Kotor (Kg)', 'Tara (Kg)', 'Potongan (Kg)', 'Berat Bersih (Kg)',
      'Harga/Kg', 'Subtotal', 'Admin', 'Total Transfer',
      'Status Pembayaran', 'Dibayar', 'Terutang',
      'A/N Rekening', 'No. Rekening', 'Bank'
    ];

    const rows = filteredTransactions.map(t => {
      const supplier = getSupplierInfo(t.namaSupplier);
      return [
        t.tanggal, t.namaSupplier, t.jam, t.namaSupir, t.platNomor,
        t.beratKotor, t.tara, t.potonganKg, t.beratBersih,
        t.hargaPerKg, t.subtotal, t.biayaAdmin, t.totalTransfer,
        t.statusPembayaran || 'LUNAS', t.dibayar || t.totalTransfer, t.terutang || 0,
        supplier?.namaRekening || '', supplier?.noRekening || '', supplier?.bank || ''
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `timbangan_gas_jaya_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <Card className="w-full">
      <CardHeader className="bg-gradient-to-r from-green-600 to-green-800 text-white rounded-t-lg">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-xl">
            <FileSpreadsheet className="w-6 h-6" />
            Riwayat Transaksi
          </CardTitle>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Cari transaksi..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64 bg-white text-gray-900"
              />
            </div>
            <Button variant="secondary" onClick={exportToCSV} className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[500px]">
          <Table>
            <TableHeader className="sticky top-0 bg-gray-50">
              <TableRow>
                <TableHead className="w-32">Tanggal</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead className="w-20">Jam</TableHead>
                <TableHead>Berat Bersih</TableHead>
                <TableHead>Harga/Kg</TableHead>
                <TableHead>Total Transfer</TableHead>
                <TableHead className="w-28 text-center">Status</TableHead>
                <TableHead className="w-32 text-center">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    Belum ada data transaksi
                  </TableCell>
                </TableRow>
              ) : (
                filteredTransactions.map((transaction) => (
                  <TableRow key={transaction.id} className="hover:bg-gray-50">
                    <TableCell>{transaction.tanggal}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-medium">
                        {transaction.namaSupplier}
                      </Badge>
                    </TableCell>
                    <TableCell>{transaction.jam}</TableCell>
                    <TableCell className="font-mono">
                      {transaction.beratBersih.toLocaleString('id-ID')} Kg
                    </TableCell>
                    <TableCell className="font-mono">
                      Rp {transaction.hargaPerKg.toLocaleString('id-ID')}
                    </TableCell>
                    <TableCell className="font-mono font-semibold text-green-700">
                      {formatRupiah(transaction.totalTransfer)}
                    </TableCell>
                    <TableCell className="text-center">
                      <button
                        onClick={() => {
                          if (onUpdate) {
                            const newStatus = transaction.statusPembayaran === 'LUNAS' ? 'BELUM LUNAS' : 'LUNAS';
                            onUpdate(transaction.id!, {
                              statusPembayaran: newStatus,
                              dibayar: newStatus === 'LUNAS' ? transaction.totalTransfer : (transaction.dibayar || 0),
                              terutang: newStatus === 'LUNAS' ? 0 : (transaction.totalTransfer - (transaction.dibayar || 0))
                            });
                          }
                        }}
                        className="cursor-pointer"
                      >
                        {transaction.statusPembayaran === 'LUNAS' || !transaction.statusPembayaran ? (
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-200 border-green-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            LUNAS
                          </Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800 hover:bg-red-200 border-red-300 flex items-center gap-1">
                            <XCircle className="w-3 h-3" />
                            BELUM
                          </Badge>
                        )}
                      </button>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex justify-center gap-1">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setSelectedTransaction(transaction)}
                            >
                              <Eye className="w-4 h-4 text-blue-600" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle className="flex items-center gap-2">
                                <Truck className="w-5 h-5" />
                                Detail Transaksi
                              </DialogTitle>
                            </DialogHeader>
                            {selectedTransaction && (
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="bg-gray-50 p-3 rounded">
                                    <Label className="text-gray-500 text-sm">Tanggal & Jam</Label>
                                    <div className="font-medium">
                                      {selectedTransaction.tanggal} {selectedTransaction.jam}
                                    </div>
                                  </div>
                                  <div className="bg-gray-50 p-3 rounded">
                                    <Label className="text-gray-500 text-sm">Supplier</Label>
                                    <div className="font-medium">{selectedTransaction.namaSupplier}</div>
                                  </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="bg-gray-50 p-3 rounded">
                                    <Label className="text-gray-500 text-sm">Nama Supir</Label>
                                    <div className="font-medium flex items-center gap-2">
                                      <User className="w-4 h-4" />
                                      {selectedTransaction.namaSupir}
                                    </div>
                                  </div>
                                  <div className="bg-gray-50 p-3 rounded">
                                    <Label className="text-gray-500 text-sm">Plat Nomor</Label>
                                    <div className="font-medium">{selectedTransaction.platNomor}</div>
                                  </div>
                                </div>
                                <div className="border-t pt-4">
                                  <h4 className="font-semibold mb-2">Perhitungan Berat</h4>
                                  <div className="grid grid-cols-4 gap-2 text-sm">
                                    <div className="bg-blue-50 p-2 rounded text-center">
                                      <div className="text-gray-500">Kotor</div>
                                      <div className="font-mono font-bold">{selectedTransaction.beratKotor}</div>
                                    </div>
                                    <div className="bg-orange-50 p-2 rounded text-center">
                                      <div className="text-gray-500">Tara</div>
                                      <div className="font-mono font-bold">{selectedTransaction.tara}</div>
                                    </div>
                                    <div className="bg-red-50 p-2 rounded text-center">
                                      <div className="text-gray-500">Potongan</div>
                                      <div className="font-mono font-bold">{selectedTransaction.potonganKg}</div>
                                    </div>
                                    <div className="bg-green-50 p-2 rounded text-center">
                                      <div className="text-gray-500">Bersih</div>
                                      <div className="font-mono font-bold text-green-700">{selectedTransaction.beratBersih}</div>
                                    </div>
                                  </div>
                                </div>
                                <div className="border-t pt-4">
                                  <h4 className="font-semibold mb-2">Informasi Rekening</h4>
                                  {(() => {
                                    const supplier = getSupplierInfo(selectedTransaction.namaSupplier);
                                    return supplier ? (
                                      <div className="grid grid-cols-2 gap-4 text-sm">
                                        <div className="bg-gray-50 p-2 rounded">
                                          <div className="text-gray-500">A/N Rekening</div>
                                          <div className="font-medium">{supplier.namaRekening}</div>
                                        </div>
                                        <div className="bg-gray-50 p-2 rounded">
                                          <div className="text-gray-500">No. Rekening</div>
                                          <div className="font-mono">{supplier.noRekening}</div>
                                        </div>
                                        <div className="bg-gray-50 p-2 rounded">
                                          <div className="text-gray-500">Bank</div>
                                          <div className="font-medium">{supplier.bank}</div>
                                        </div>
                                      </div>
                                    ) : null;
                                  })()}
                                </div>
                                <div className="border-t pt-4">
                                  <h4 className="font-semibold mb-2">Status Pembayaran</h4>
                                  <div className="grid grid-cols-3 gap-4 text-sm">
                                    <div className={`p-3 rounded text-center ${
                                      selectedTransaction.statusPembayaran === 'LUNAS' || !selectedTransaction.statusPembayaran
                                        ? 'bg-green-100 border border-green-300' 
                                        : 'bg-red-100 border border-red-300'
                                    }`}>
                                      <div className="text-gray-500">Status</div>
                                      <div className={`font-bold flex items-center justify-center gap-1 ${
                                        selectedTransaction.statusPembayaran === 'LUNAS' || !selectedTransaction.statusPembayaran
                                          ? 'text-green-700' 
                                          : 'text-red-700'
                                      }`}>
                                        {selectedTransaction.statusPembayaran === 'LUNAS' || !selectedTransaction.statusPembayaran ? (
                                          <><CheckCircle2 className="w-4 h-4" /> LUNAS</>
                                        ) : (
                                          <><XCircle className="w-4 h-4" /> BELUM LUNAS</>
                                        )}
                                      </div>
                                    </div>
                                    <div className="bg-blue-50 p-3 rounded text-center border border-blue-200">
                                      <div className="text-gray-500">Dibayar</div>
                                      <div className="font-mono font-bold text-blue-700">
                                        {formatRupiah(selectedTransaction.dibayar || selectedTransaction.totalTransfer)}
                                      </div>
                                    </div>
                                    <div className={`p-3 rounded text-center border ${
                                      (selectedTransaction.terutang || 0) > 0 
                                        ? 'bg-red-50 border-red-300' 
                                        : 'bg-green-50 border-green-300'
                                    }`}>
                                      <div className="text-gray-500">Terutang</div>
                                      <div className={`font-mono font-bold ${
                                        (selectedTransaction.terutang || 0) > 0 
                                          ? 'text-red-700' 
                                          : 'text-green-700'
                                      }`}>
                                        {formatRupiah(selectedTransaction.terutang || 0)}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="bg-green-100 p-4 rounded-lg border-2 border-green-300">
                                  <div className="flex justify-between items-center">
                                    <span className="text-green-800 font-semibold">Total Transfer:</span>
                                    <span className="text-2xl font-bold text-green-900">
                                      {formatRupiah(selectedTransaction.totalTransfer)}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm('Yakin ingin menghapus transaksi ini?')) {
                              onDelete(transaction.id!);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </ScrollArea>
        <div className="p-4 border-t bg-gray-50">
          <div className="flex justify-between items-center text-sm text-gray-600">
            <span>Total Transaksi: {filteredTransactions.length}</span>
            <span>
              Total Nilai: {' '}
              <span className="font-bold text-green-700">
                {formatRupiah(filteredTransactions.reduce((sum, t) => sum + t.totalTransfer, 0))}
              </span>
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
