import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calculator, Save, RotateCcw, Wallet, CheckCircle2, XCircle } from 'lucide-react';
import type { WeighingData, Supplier } from '@/types';

interface WeighingFormProps {
  suppliers: Supplier[];
  onSave: (data: WeighingData) => void;
}

export function WeighingForm({ suppliers, onSave }: WeighingFormProps) {
  const [formData, setFormData] = useState<Partial<WeighingData>>({
    tanggal: new Date().toISOString().split('T')[0],
    jam: new Date().toTimeString().slice(0, 5),
    potonganPersen: 0.02,
    biayaAdmin: 0,
  });

  const [calculated, setCalculated] = useState({
    potonganKg: 0,
    beratBersih: 0,
    subtotal: 0,
    totalTransfer: 0,
    terutang: 0,
  });

  // Auto-calculate when weight values change
  useEffect(() => {
    const beratKotor = Number(formData.beratKotor) || 0;
    const tara = Number(formData.tara) || 0;
    const potonganPersen = Number(formData.potonganPersen) || 0;
    const hargaPerKg = Number(formData.hargaPerKg) || 0;
    const biayaAdmin = Number(formData.biayaAdmin) || 0;
    const dibayar = Number(formData.dibayar) || 0;
    const statusPembayaran = formData.statusPembayaran || 'LUNAS';

    const beratBersih = Math.max(0, beratKotor - tara);
    const potonganKg = Math.round(beratBersih * potonganPersen);
    const beratFinal = beratBersih - potonganKg;
    const subtotal = beratFinal * hargaPerKg;
    const totalTransfer = subtotal + biayaAdmin;
    
    // Calculate terutang based on status
    const terutang = statusPembayaran === 'LUNAS' ? 0 : Math.max(0, totalTransfer - dibayar);

    setCalculated({
      potonganKg,
      beratBersih: beratFinal,
      subtotal,
      totalTransfer,
      terutang,
    });
  }, [formData.beratKotor, formData.tara, formData.potonganPersen, formData.hargaPerKg, formData.biayaAdmin, formData.dibayar, formData.statusPembayaran]);

  // Auto-fill when supplier is selected
  const handleSupplierChange = (supplierName: string) => {
    const supplier = suppliers.find(s => s.namaSupplier === supplierName);
    if (supplier) {
      setFormData(prev => ({
        ...prev,
        namaSupplier: supplierName,
        hargaPerKg: supplier.hargaTerakhir,
      }));
    }
  };

  const handleSubmit = () => {
    if (!formData.namaSupir || !formData.platNomor || !formData.namaSupplier) {
      alert('Mohon lengkapi data supir, plat nomor, dan supplier!');
      return;
    }

    const completeData: WeighingData = {
      id: Date.now().toString(),
      tanggal: formData.tanggal || new Date().toISOString().split('T')[0],
      jam: formData.jam || new Date().toTimeString().slice(0, 5),
      namaSupir: formData.namaSupir || '',
      platNomor: formData.platNomor || '',
      namaSupplier: formData.namaSupplier || '',
      beratKotor: Number(formData.beratKotor) || 0,
      tara: Number(formData.tara) || 0,
      potonganPersen: Number(formData.potonganPersen) || 0.02,
      potonganKg: calculated.potonganKg,
      beratBersih: calculated.beratBersih,
      hargaPerKg: Number(formData.hargaPerKg) || 0,
      subtotal: calculated.subtotal,
      biayaAdmin: Number(formData.biayaAdmin) || 0,
      totalTransfer: calculated.totalTransfer,
      statusPembayaran: formData.statusPembayaran || 'LUNAS',
      dibayar: formData.statusPembayaran === 'LUNAS' ? calculated.totalTransfer : (Number(formData.dibayar) || 0),
      terutang: calculated.terutang,
    };

    onSave(completeData);
    
    // Reset form but keep date and time
    setFormData({
      tanggal: new Date().toISOString().split('T')[0],
      jam: new Date().toTimeString().slice(0, 5),
      potonganPersen: 0.02,
      biayaAdmin: 0,
      statusPembayaran: 'LUNAS',
      dibayar: 0,
      terutang: 0,
    });
  };

  const handleReset = () => {
    setFormData({
      tanggal: new Date().toISOString().split('T')[0],
      jam: new Date().toTimeString().slice(0, 5),
      potonganPersen: 0.02,
      biayaAdmin: 0,
      statusPembayaran: 'LUNAS',
      dibayar: 0,
      terutang: 0,
    });
  };

  const formatRupiah = (value: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(value);
  };

  return (
    <Card className="w-full">
      <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-2 text-xl">
          <Calculator className="w-6 h-6" />
          Form Input Timbangan
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {/* Header Info */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <Label htmlFor="tanggal">Tanggal</Label>
            <Input
              id="tanggal"
              type="date"
              value={formData.tanggal || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, tanggal: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="jam">Jam</Label>
            <Input
              id="jam"
              type="time"
              value={formData.jam || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, jam: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="namaSupir">Nama Supir</Label>
            <Input
              id="namaSupir"
              placeholder="Nama supir..."
              value={formData.namaSupir || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, namaSupir: e.target.value }))}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="platNomor">Plat Nomor</Label>
            <Input
              id="platNomor"
              placeholder="Contoh: KT3432GA"
              value={formData.platNomor || ''}
              onChange={(e) => setFormData(prev => ({ ...prev, platNomor: e.target.value }))}
            />
          </div>
        </div>

        {/* Supplier */}
        <div className="space-y-2">
          <Label htmlFor="supplier">Nama Supplier</Label>
          <Select onValueChange={handleSupplierChange} value={formData.namaSupplier}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih supplier..." />
            </SelectTrigger>
            <SelectContent>
              {suppliers.map((supplier) => (
                <SelectItem key={supplier.namaSupplier} value={supplier.namaSupplier}>
                  {supplier.namaSupplier} - Rp {supplier.hargaTerakhir.toLocaleString('id-ID')}/kg
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Weight Calculations */}
        <div className="bg-gray-50 p-4 rounded-lg border">
          <h3 className="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <Calculator className="w-4 h-4" />
            Perhitungan Berat
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="beratKotor">Berat Kotor (Kg)</Label>
              <Input
                id="beratKotor"
                type="number"
                placeholder="0"
                value={formData.beratKotor || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, beratKotor: Number(e.target.value) }))}
                className="text-lg font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tara">Tara (Kg)</Label>
              <Input
                id="tara"
                type="number"
                placeholder="0"
                value={formData.tara || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, tara: Number(e.target.value) }))}
                className="text-lg font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="potonganPersen">Potongan (%)</Label>
              <Input
                id="potonganPersen"
                type="number"
                step="0.01"
                value={formData.potonganPersen || 0.02}
                onChange={(e) => setFormData(prev => ({ ...prev, potonganPersen: Number(e.target.value) }))}
                className="text-lg font-mono"
              />
            </div>
          </div>

          {/* Results */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="bg-blue-50 p-3 rounded border border-blue-200">
              <Label className="text-blue-600 text-sm">Potongan (Kg)</Label>
              <div className="text-xl font-bold text-blue-800 font-mono">
                {calculated.potonganKg.toLocaleString('id-ID')} Kg
              </div>
            </div>
            <div className="bg-green-50 p-3 rounded border border-green-200">
              <Label className="text-green-600 text-sm">Berat Bersih (Kg)</Label>
              <div className="text-xl font-bold text-green-800 font-mono">
                {calculated.beratBersih.toLocaleString('id-ID')} Kg
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="hargaPerKg">Harga per Kg (Rp)</Label>
              <Input
                id="hargaPerKg"
                type="number"
                placeholder="0"
                value={formData.hargaPerKg || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, hargaPerKg: Number(e.target.value) }))}
                className="text-lg font-mono"
              />
            </div>
          </div>
        </div>

        {/* Financial Summary */}
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
          <h3 className="font-semibold text-green-800 mb-4">Ringkasan Keuangan</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="subtotal" className="text-green-700">Subtotal (Rp)</Label>
              <div className="text-2xl font-bold text-green-800 font-mono bg-white p-2 rounded border">
                {formatRupiah(calculated.subtotal)}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="biayaAdmin" className="text-green-700">Biaya Admin (Rp)</Label>
              <Input
                id="biayaAdmin"
                type="number"
                placeholder="0"
                value={formData.biayaAdmin || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, biayaAdmin: Number(e.target.value) }))}
                className="text-lg font-mono"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-green-700">Total Transfer (Rp)</Label>
              <div className="text-3xl font-bold text-green-900 font-mono bg-white p-2 rounded border-2 border-green-500">
                {formatRupiah(calculated.totalTransfer)}
              </div>
            </div>
          </div>
        </div>

        {/* Payment Status */}
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-4 rounded-lg border border-amber-200">
          <h3 className="font-semibold text-amber-800 mb-4 flex items-center gap-2">
            <Wallet className="w-5 h-5" />
            Status Pembayaran
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-amber-700">Status</Label>
              <Select 
                onValueChange={(value: 'LUNAS' | 'BELUM LUNAS') => 
                  setFormData(prev => ({ 
                    ...prev, 
                    statusPembayaran: value,
                    dibayar: value === 'LUNAS' ? calculated.totalTransfer : 0
                  }))
                } 
                value={formData.statusPembayaran || 'LUNAS'}
              >
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="Pilih status..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LUNAS">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      LUNAS
                    </div>
                  </SelectItem>
                  <SelectItem value="BELUM LUNAS">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-600" />
                      BELUM LUNAS
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dibayar" className="text-amber-700">Jumlah Dibayar (Rp)</Label>
              <Input
                id="dibayar"
                type="number"
                placeholder="0"
                disabled={formData.statusPembayaran === 'LUNAS'}
                value={formData.statusPembayaran === 'LUNAS' ? calculated.totalTransfer : (formData.dibayar || '')}
                onChange={(e) => setFormData(prev => ({ ...prev, dibayar: Number(e.target.value) }))}
                className="text-lg font-mono bg-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-amber-700">Terutang (Rp)</Label>
              <div className={`text-2xl font-bold font-mono bg-white p-2 rounded border-2 ${
                calculated.terutang > 0 ? 'text-red-700 border-red-400' : 'text-green-700 border-green-400'
              }`}>
                {formatRupiah(calculated.terutang)}
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={handleReset} className="flex items-center gap-2">
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
          <Button onClick={handleSubmit} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4" />
            Simpan Transaksi
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
