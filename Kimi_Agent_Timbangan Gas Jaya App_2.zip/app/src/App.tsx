import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster, toast } from 'sonner';
import { Scale, FileSpreadsheet, Users, Download } from 'lucide-react';
import { WeighingForm } from '@/components/WeighingForm';
import { TransactionTable } from '@/components/TransactionTable';
import { SupplierManager } from '@/components/SupplierManager';
import { PWAInstallPrompt } from '@/components/PWAInstallPrompt';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { WeighingData, Supplier } from '@/types';
import './App.css';

// Initial suppliers data from the Excel file
const initialSuppliers: Supplier[] = [
  { namaSupplier: 'SAMURAI', namaRekening: 'ABDU AL AMIN', noRekening: '1490013834462', bank: 'MANDIRI', hargaTerakhir: 3750 },
  { namaSupplier: 'ADI', namaRekening: 'MARLIA', noRekening: '1480014198686', bank: 'MANDIRI', hargaTerakhir: 3600 },
  { namaSupplier: 'ZULKIFLI', namaRekening: 'ZULKIFLI', noRekening: '1480018610314', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'PUTRA TUNGGAL', namaRekening: 'SUKIMAN', noRekening: '450701013578531', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'EDI', namaRekening: 'EDY MUHAMMAD NUR', noRekening: '1480013103893', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'WALDI', namaRekening: 'NOORDIANSYAH', noRekening: '738501005313532', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'BUHARI', namaRekening: 'HARIATI', noRekening: '44801001259565', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'HAMSAH', namaRekening: 'HAMSAH', noRekening: '360301050877537', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'ABD RAHIM', namaRekening: 'ABD RAHIM', noRekening: '360301050877537', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'UDIN', namaRekening: 'UDIN / ROHANI', noRekening: '1480013762920 / 087786778677', bank: 'MANDIRI / DANA', hargaTerakhir: 3650 },
  { namaSupplier: 'NISA', namaRekening: 'HAIRUN NISA', noRekening: '1480016003876', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'ADAM', namaRekening: 'ADAM P', noRekening: '1480018457203', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'JERMAN', namaRekening: 'JERMAN', noRekening: '460201004651536', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'MAMA ICA', namaRekening: 'IRAWATI', noRekening: '7935766478', bank: 'BCA', hargaTerakhir: 3650 },
  { namaSupplier: 'IPPUNG', namaRekening: 'ABD RAHIM', noRekening: '1480017730915', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'WIDODO', namaRekening: 'TEGUH WIDOO', noRekening: '1480018948680', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'WALDI WIWIK', namaRekening: 'WIWIK', noRekening: '360301030386538', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'KOMAR', namaRekening: 'KOMAR', noRekening: '1480022254125', bank: 'MANDIRI', hargaTerakhir: 3650 },
  { namaSupplier: 'JUMLI', namaRekening: 'JUMLI', noRekening: '1952932364', bank: 'BNI', hargaTerakhir: 3650 },
  { namaSupplier: 'SALO CELLA', namaRekening: 'HARIATI', noRekening: '44801001259565', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'ILYAS SANTAN', namaRekening: 'ELIAS', noRekening: '510601017631536', bank: 'BRI', hargaTerakhir: 3650 },
  { namaSupplier: 'SAID TANAH DATAR', namaRekening: 'NOVRI', noRekening: '008201003352569', bank: 'BRI', hargaTerakhir: 3600 },
  { namaSupplier: 'HARIATI MDRI', namaRekening: 'HARIATI', noRekening: '1480015050928', bank: 'MANDIRI', hargaTerakhir: 3600 },
  { namaSupplier: 'ACIL', namaRekening: 'SABRANSAH', noRekening: '360301026090535', bank: 'BRI', hargaTerakhir: 3600 },
];

function App() {
  const [transactions, setTransactions] = useLocalStorage<WeighingData[]>('timbangan-transactions', []);
  const [suppliers, setSuppliers] = useLocalStorage<Supplier[]>('timbangan-suppliers', initialSuppliers);
  const [activeTab, setActiveTab] = useState('input');

  const handleSaveTransaction = (data: WeighingData) => {
    setTransactions(prev => [data, ...prev]);
    toast.success('Transaksi berhasil disimpan!', {
      description: `${data.namaSupplier} - ${data.beratBersih.toLocaleString('id-ID')} Kg - Rp ${data.totalTransfer.toLocaleString('id-ID')}`,
    });
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
    toast.success('Transaksi berhasil dihapus');
  };

  const handleUpdateTransaction = (id: string, data: Partial<WeighingData>) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, ...data } : t));
    toast.success('Status pembayaran diperbarui!');
  };

  const handleAddSupplier = (supplier: Supplier) => {
    setSuppliers(prev => [...prev, supplier]);
    toast.success('Supplier berhasil ditambahkan!');
  };

  const handleDeleteSupplier = (namaSupplier: string) => {
    setSuppliers(prev => prev.filter(s => s.namaSupplier !== namaSupplier));
    toast.success('Supplier berhasil dihapus');
  };

  const exportAllToCSV = () => {
    const headers = [
      'Tanggal', 'Jam', 'Nama Supir', 'Plat Nomor', 'Supplier',
      'Berat Kotor (Kg)', 'Tara (Kg)', 'Potongan (Kg)', 'Berat Bersih (Kg)',
      'Harga/Kg', 'Subtotal', 'Admin', 'Total Transfer',
      'Status Pembayaran', 'Dibayar', 'Terutang'
    ];

    const rows = transactions.map(t => [
      t.tanggal, t.jam, t.namaSupir, t.platNomor, t.namaSupplier,
      t.beratKotor, t.tara, t.potonganKg, t.beratBersih,
      t.hargaPerKg, t.subtotal, t.biayaAdmin, t.totalTransfer,
      t.statusPembayaran || 'LUNAS', t.dibayar || t.totalTransfer, t.terutang || 0
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `timbangan_gas_jaya_all_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();

    toast.success('Data berhasil diexport ke CSV!');
  };



  // Calculate summary statistics
  const totalTransactions = transactions.length;
  const totalWeight = transactions.reduce((sum, t) => sum + t.beratBersih, 0);
  const totalValue = transactions.reduce((sum, t) => sum + t.totalTransfer, 0);
  const uniqueSuppliers = new Set(transactions.map(t => t.namaSupplier)).size;
  const belumLunasCount = transactions.filter(t => t.statusPembayaran === 'BELUM LUNAS').length;
  const totalTerutang = transactions.reduce((sum, t) => sum + (t.terutang || 0), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Toaster position="top-right" richColors />
      
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-800 to-indigo-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-3 rounded-lg">
                <Scale className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">TIMBANGAN GAS JAYA</h1>
                <p className="text-blue-200 text-sm">Sistem Pencatatan Timbangan & Transaksi</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={exportAllToCSV}
                className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-sm"
              >
                <Download className="w-4 h-4" />
                Export Semua Data
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Summary Cards */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-blue-500">
            <div className="text-gray-500 text-sm">Total Transaksi</div>
            <div className="text-2xl font-bold text-gray-800">{totalTransactions}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-green-500">
            <div className="text-gray-500 text-sm">Total Berat Bersih</div>
            <div className="text-2xl font-bold text-green-700">
              {totalWeight.toLocaleString('id-ID')} <span className="text-sm">Kg</span>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-purple-500">
            <div className="text-gray-500 text-sm">Total Nilai</div>
            <div className="text-2xl font-bold text-purple-700">
              Rp {(totalValue / 1000000).toFixed(1)}M
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4 border-l-4 border-orange-500">
            <div className="text-gray-500 text-sm">Supplier Aktif</div>
            <div className="text-2xl font-bold text-orange-700">{uniqueSuppliers}</div>
          </div>
          <div className={`rounded-lg shadow p-4 border-l-4 ${belumLunasCount > 0 ? 'bg-red-50 border-red-500' : 'bg-white border-green-500'}`}>
            <div className="text-gray-500 text-sm">Belum Lunas</div>
            <div className={`text-2xl font-bold ${belumLunasCount > 0 ? 'text-red-700' : 'text-green-700'}`}>
              {belumLunasCount} <span className="text-sm">transaksi</span>
            </div>
            {totalTerutang > 0 && (
              <div className="text-xs text-red-600 mt-1">
                Terutang: Rp {totalTerutang.toLocaleString('id-ID')}
              </div>
            )}
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="input" className="flex items-center gap-2">
              <Scale className="w-4 h-4" />
              Input Timbangan
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4" />
              Riwayat Transaksi
            </TabsTrigger>
            <TabsTrigger value="suppliers" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Data Supplier
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input" className="mt-0">
            <WeighingForm suppliers={suppliers} onSave={handleSaveTransaction} />
          </TabsContent>

          <TabsContent value="transactions" className="mt-0">
            <TransactionTable 
              transactions={transactions} 
              suppliers={suppliers}
              onDelete={handleDeleteTransaction}
              onUpdate={handleUpdateTransaction}
            />
          </TabsContent>

          <TabsContent value="suppliers" className="mt-0">
            <SupplierManager 
              suppliers={suppliers} 
              onAdd={handleAddSupplier}
              onDelete={handleDeleteSupplier}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-400 py-4 mt-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm">
          <p>TIMBANGAN GAS JAYA - Sistem Pencatatan Timbangan</p>
          <p className="text-gray-500 mt-1">Export ke CSV untuk import ke Google Sheets</p>
        </div>
      </footer>

      {/* PWA Install Prompt */}
      <PWAInstallPrompt />
    </div>
  );
}

export default App;
